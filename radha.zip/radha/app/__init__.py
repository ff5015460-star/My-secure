from flask import Flask, render_template, session, g, request, redirect, url_for, flash
from app.config import Config
from app.database.connection import init_db, create_all_tables, db_session
from app.services.user_manager import UserManager
from app.core.exceptions import PermissionDeniedError
from app.routes.decorators import generate_csrf_token, validate_csrf
from app.routes.auth_routes import auth_bp
from app.routes.dashboard_routes import dashboard_bp
from app.routes.file_routes import file_bp
from app.routes.admin_routes import admin_bp


def create_app(config_class=Config) -> Flask:
    """Application factory for SecureShare."""
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize SQLAlchemy database engine and session
    init_db(app.config["SQLALCHEMY_DATABASE_URI"])
    create_all_tables()

    # Context processors
    @app.context_processor
    def inject_utilities():
        return {
            "csrf_token": generate_csrf_token,
            "current_user": getattr(g, "current_user", None)
        }

    # Request hooks
    @app.before_request
    def load_authenticated_user():
        g.current_user = None
        user_id = session.get("user_id")
        if user_id:
            user_mgr = UserManager(db_session)
            user = user_mgr.get_by_id(user_id)
            if user:
                if not user.is_active:
                    session.clear()
                    flash("Your account has been deactivated by an administrator.", "danger")
                else:
                    g.current_user = user
            else:
                session.clear()

        # CSRF validation for state-changing requests
        if not app.config.get("TESTING", False):
            if request.endpoint and not request.endpoint.startswith("static"):
                validate_csrf()

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        db_session.remove()

    # Custom Error Handlers
    @app.errorhandler(PermissionDeniedError)
    def handle_permission_denied(error):
        return render_template(
            "errors/403.html",
            error_message=str(error),
            required_permission=getattr(error, "required_permission", None)
        ), 403

    @app.errorhandler(403)
    def error_403(error):
        return render_template(
            "errors/403.html",
            error_message="Access Denied: You do not have permission to view or access this resource."
        ), 403

    @app.errorhandler(404)
    def error_404(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def error_500(error):
        db_session.rollback()
        return render_template("errors/500.html"), 500

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(file_bp)
    app.register_blueprint(admin_bp)

    return app
